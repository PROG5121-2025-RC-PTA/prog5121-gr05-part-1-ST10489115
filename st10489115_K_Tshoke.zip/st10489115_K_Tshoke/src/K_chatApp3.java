import java.util.Scanner;

public class K_chatApp3 {

    private static String registeredUsername;
    private static String registeredPassword;
    private static String registeredPhoneNumber;
    private static String firstName;
    private static String lastName;

    private static boolean isLoggedIn = false;
    private static Message[] recentMessages = new Message[10];
    static int messageIndex = 0;

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("Hello, Welcome to K_chatApp");

        // Register and Login
        Registration(input);
        Login(input);

        if (isLoggedIn) {
            while (isLoggedIn) {
                System.out.println("\n1. Send Messages");
                System.out.println("2. Show recently sent messages");
                System.out.println("3. Logout");
                System.out.print("Choose an option: ");
                int option = input.nextInt();
                input.nextLine();

                switch (option) {
                    case 1:
                        sendMessage(input);
                        break;
                    case 2:
                        showRecentMessages();
                        break;
                    case 3:
                        isLoggedIn = false;
                        System.out.println("Logged out successfully");
                        break;
                    default:
                        System.out.println("Invalid option");
                }
            }
        }
    }

    public static void Registration(Scanner input) {
        System.out.println("\nRegistration");

        System.out.print("Please enter your first name: ");
        firstName = input.nextLine();

        System.out.print("Please enter your last name: ");
        lastName = input.nextLine();

        System.out.print("Enter a username (must contain '_' and be max 5 characters): ");
        String username = input.nextLine();

        if (username.contains("_") && username.length() <= 5) {
            System.out.println("Username successfully captured.");
            registeredUsername = username;
        } else {
            System.out.println("Username is not correctly formatted, please ensure it contains an underscore and no more than five characters.");
            System.exit(0);
        }

        System.out.print("Please enter password with a minimum of 8 characters: ");
        String password = input.nextLine();

        if (password.length() >= 8) {
            System.out.println("Password successfully captured.");
            registeredPassword = password;
        } else {
            System.out.println("Password is too short.");
            System.exit(0);
        }

        System.out.print("Enter your SA phone number (e.g. +27831234567): ");
        String phone = input.nextLine();

        if (phone.matches("\\+27\\d{9}")) {
            System.out.println("Cell phone number successfully added.");
            registeredPhoneNumber = phone;
        } else {
            System.out.println("Cell phone number incorrectly formatted.");
            System.exit(0);
        }
    }

    public static void Login(Scanner input) {
        System.out.println("\nLogin");

        System.out.print("Enter your username: ");
        String username = input.nextLine();

        System.out.print("Enter your password: ");
        String password = input.nextLine();

        if (username.equals(registeredUsername) && password.equals(registeredPassword)) {
            isLoggedIn = true;
            System.out.println("Welcome " + firstName + " " + lastName + ", welcome to K_chatApp.");
        } else {
            System.out.println("Username or password incorrect, please try again.");
            System.exit(0);
        }
    }

    private static void sendMessage(Scanner scanner) {
        System.out.print("How many messages do you want to send? ");
        int numMessages = scanner.nextInt();
        scanner.nextLine(); // consume newline

        for (int i = 0; i < numMessages; i++) {
            System.out.print("Enter Message ID (max 10 chars): ");
            String id = scanner.nextLine();

            System.out.print("Enter Recipient Cell Number (starts with 0, max 10 digits): ");
            String cell = scanner.nextLine();

            System.out.print("Enter your Message: ");
            String content = scanner.nextLine();

            Message msg = new Message(id, cell, content);

            if (!msg.checkMessageID()) {
                System.out.println("Invalid Message ID. Skipping message.");
                continue;
            }

            if (!msg.checkRecipientCell()) {
                System.out.println("Invalid Cell Number. Skipping message.");
                continue;
            }

            System.out.print("Do you want to (1) Send, (2) Store, or (3) Discard this message? ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            if (choice == 1 || choice == 2) {
                recentMessages[messageIndex % 10] = msg;
                messageIndex++;
                System.out.println("Message processed. Hash: " + msg.createMessageHash());
            } else if (choice == 3) {
                System.out.println("Message discarded.");
            } else {
                System.out.println("Invalid choice. Message skipped.");
            }
        }
    }

    private static void showRecentMessages() {
        System.out.println("\n--- Recent Messages ---");

        if (messageIndex == 0) {
            System.out.println("No messages to show yet.");
            return;
        }

        int totalMessages = Math.min(messageIndex, 10); // show up to 10
        for (int i = 0; i < totalMessages; i++) {
            int index = (messageIndex - totalMessages + i) % 10;
            Message msg = recentMessages[index];
            if (msg != null) {
                System.out.println(msg.printMessages());
            }
        }
    }
}

class Message {
    private String messageID;
    private String recipientCell;
    private String messageContent;

    public Message(String messageID, String recipientCell, String messageContent) {
        this.messageID = messageID;
        this.recipientCell = recipientCell;
        this.messageContent = messageContent;
    }

    public boolean checkMessageID() {
        return messageID.length() <= 10;
    }

    public boolean checkRecipientCell() {
        return recipientCell.length() == 10 && recipientCell.startsWith("0");
    }

    public String createMessageHash() {
        return Integer.toHexString((messageID + recipientCell + messageContent).hashCode());
    }

    public String sendMessage() {
        return "To: " + recipientCell + " | Message: " + messageContent;
    }

    public static int returnTotalMessages() {
        return K_chatApp3.messageIndex;
    }

    public void storeMessage() {
       
    }

    public String printMessages() {
        return sendMessage();
    }
}
